<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles responses from Suntech Payments
 */
class WC_Gateway_SunTech_Response
{
    // SunTech Payment Transaction Password
    private $webpwd;

    // Received values for SunTech Payment
    protected $posted;
    protected $urldecode_list;

    // SunTech Payment Type
    protected $payment_type;

    public function __construct($payment_type)
    {
        $this->payment_type = $payment_type;
        $this->posted = array(
            'buysafeno' => '', //*
            'web' => '', //*
            'MN' => '',
            'note1' => '',
            'note2' => '',
            'SendType' => 0,
            'errcode' => '',
            'errmsg' => '',
            'ChkValue' => '',
            'EntityATM' => '',
            'PayType' => 0,
            'paycode' => '',
            'CargoNo' => '',
            'StoreType' => '',
            'StoreName' => '',
            'StoreMsg' => ''
        );

        $this->urldecode_list = array('note1', 'note2', 'errmsg', 'StoreName', 'StoreMsg');

        add_action('woocommerce_api_wc_gateway_' . $payment_type, array($this, 'check_response'));
        // add_action('valid-suntech-request', array($this, 'valid_response'));
    }

    /**
     * Check for SunTech Payment Response.
     */
    public function check_response()
    {
        if (!empty($_POST) && $this->validate_suntech_args()) {
            $posted = wp_unslash($_POST);

            foreach ($posted as $key => $value) {
                $this->posted[$key] = (in_array($key, $this->urldecode_list)) ? urldecode($value) : $value;
            }

            if ($this->payment_type == 'suntech_buysafe' || $this->payment_type == 'suntech_24pay') {
                $this->payment_type = $this->get_note1_arg('payment_type');
            }

            // Get SunTech Payment Transaction Password
            $setting = get_option('woocommerce_' . $this->payment_type . '_settings');
            $this->webpwd = $setting['web_password_value'];

            $this->valid_response();
            // do_action('valid-suntech-request');
            exit;
        }

        wp_die('SunTech Payment Request Failure', 'SunTech Payment', array('response' => 500));
    }

    /**
     * 檢查紅陽回傳參數
     *
     * @param array $additional_validate_args
     * @return bool
     */
    public function validate_suntech_args($additional_validate_args = array())
    {
        $required_args = array('buysafeno', 'web', 'ChkValue', 'Td');
        array_merge($required_args, $additional_validate_args);
        foreach ($required_args as $arg) {
            if (!isset($arg)) return false;
        }
        return true;
    }

    public function valid_response()
    {
        $order_id = $this->posted['Td'];
        $order = $this->get_suntech_order($order_id);
        if ($order) {
            if ($this->validate_paid_response()) {
                call_user_func(array($this, 'payment_complete'), $order);
            } elseif ($this->validate_24pay_response()) {
                call_user_func(array($this, 'payment_24pay'), $order);
            } elseif ($this->validate_paycode_response()) {
                call_user_func(array($this, 'payment_paycode'), $order);
            } elseif ($this->validate_sunship_response()) {
                call_user_func(array($this, 'payment_sunship'), $order);
            } elseif ($this->validate_CVS_response()) {
                call_user_func(array($this, 'payment_CVS'), $order);
            } else {
                $this->_log(sprintf("Invalid Order. Order ID : %s, payment_type : %s, buysafeno : %s, web : %s, ChkValue : %s",
                    $order_id,
                    $this->payment_type,
                    $this->posted['buysafeno'],
                    $this->posted['web'],
                    $this->posted['ChkValue']
                ), 'error');
                wp_die('Invalid Order', 'SunTech Payment', array('response' => 500));
            }
        } else {
            wp_die('Order Doesn\'t exist', 'SunTech Payment', array('response' => 500));
        }

        exit;
    }

    /**
     * 比對 ChkValue
     *
     * @param array $args
     * @return bool
     */
    protected function validate_ChkValue($args)
    {
        if ($this->posted['ChkValue'] == '') {
            $this->_log('Received empty ChkValue', 'warning');
            return FALSE;
        }
        $args = implode('', $args);
        $suntech_ChkValue_args = $this->posted['web'] . $this->webpwd . $this->posted['buysafeno'] . $args;
        return $this->posted['ChkValue'] == WC_Gateway_Suntech_Base::get_encrypted_ChkValue($suntech_ChkValue_args);
    }

    /**
     * 取得紅陽訂單
     *
     * @param $order_id
     * @return bool|WC_Order
     */
    protected function get_suntech_order($order_id)
    {
        $order = wc_get_order($order_id);

        // Get order by order key
        // wc_get_order_id_by_order_key( $order_key );

        if (!$order) {
            $this->_log("Order doesn't exist. Order ID : " . $order_id, 'error');
            return FALSE;
        }

        return $order;
    }

    /**
     * 檢查是否來自 紅陽付款完成 回傳
     *
     * @return bool
     */
    protected function validate_paid_response()
    {
        if ($this->posted['errcode'] == '') return FALSE;
        $args = array($this->posted['MN'], $this->posted['errcode'], $this->posted['CargoNo']);
        return $this->validate_ChkValue($args);
    }

    /**
     * 檢查是否來自 紅陽 24Payment 回傳
     *
     * @return bool
     */
    protected function validate_24pay_response()
    {
        if ($this->payment_type != 'suntech_24pay' && $this->payment_type != 'suntech_atm') return false;
        $args = array($this->posted['MN'], $this->posted['EntityATM']);
        return $this->validate_ChkValue($args);
    }

    /**
     * 檢查是否來自 紅陽 Paycode 回傳
     *
     * @return bool
     */
    protected function validate_paycode_response()
    {
        if ($this->payment_type != 'suntech_paycode') return false;

        $args = array($this->posted['MN'], $this->posted['paycode']);
        return $this->validate_ChkValue($args);
    }

    /**
     * 檢查是否來自 紅陽 SunShip 回傳
     *
     * @return bool
     */
    protected function validate_sunship_response()
    {
        if ($this->payment_type != 'suntech_sunship') return false;

        $args = array($this->posted['MN'], $this->posted['CargoNo']);
        return $this->validate_ChkValue($args);
    }

    /**
     * 檢查是否來自 交貨便 回傳
     *
     * @return bool
     */
    protected function validate_CVS_response()
    {
        if ($this->posted['StoreType'] == '') return false;

        $args = array($this->posted['StoreType']);
        return $this->validate_ChkValue($args);
    }

    /**
     * 付款完成
     *
     * @param WC_Order $order
     */
    protected function payment_complete($order)
    {
        $this->save_suntech_meta_data($order);
        $errcode = $this->posted['errcode'];
        $payment_fail = FALSE;

        if ($errcode != '00') {
            $payment_fail = TRUE;
            $note = sprintf($this->_trans('Payment Fail<br />Error Message : (%s) %s<br />Please try again.'), $this->posted['errcode'], $this->posted['errmsg']);
        } else {
            $note = $this->_trans('Payment Completed');
            switch ($this->payment_type) {
                case 'suntech_buysafe':
                case 'suntech_unionpay':
                case 'suntech_webatm':
                case 'suntech_paycode':
                case 'suntech_sunship':
                    break;
                case 'suntech_atm':
                case 'suntech_24pay':
                    $_24payment_way = array(
                        '1' => $this->_trans('CVS Barcode'),
                        '2' => $this->_trans('Post Barcode'),
                        '3' => $this->_trans('Virtual Account')
                    );
                    if (array_key_exists($this->posted['PayType'], $_24payment_way)) {
                        $note .= '(' . $_24payment_way[$this->posted['PayType']] . ')';
                    } else {
                        $this->_log('Undefined Suntech 24Payment PayType : ' . $this->posted['PayType'], 'warning');
                    }
                    break;
                default:
                    $this->_log('Unknown Suntech Payment : ' . $this->payment_type, 'error');
                    wp_die('Unknown Suntech Payment', 'SunTech Payment', array('response' => 500));
            }

            // 搭配超商取貨
            if ($this->posted['CargoNo'] != '') {
                $StoreName = '7-ELEVEN - ' . $this->posted['StoreName'];
                $note .= "<br />" . sprintf(
                        $this->_trans("CVS Tracking Number : <a href='http://myship.7-11.com.tw/cc2b_track.asp?payment_no=%s' target='_blank'>%s</a><br />Pick-up Store : %s"),
                        $this->posted['CargoNo'],
                        $this->posted['CargoNo'],
                        $StoreName
                    );

                // 回填7-11門市名稱
                $shipping_info['address_1'] = $StoreName;
                $order->set_address($shipping_info, 'shipping');
            }
        }

        if ($payment_fail) $this->_add_order_note_and_response($order, $note, 'payment_fail');
        else $this->_add_order_note_and_response($order, $note, 'payment_complete');
    }

    /**
     * 24Payment 回傳
     *
     * @param WC_Order $order
     */
    protected function payment_24pay($order)
    {
        $DueDate = $this->get_note1_arg('due_date');
        if ($this->payment_type == 'suntech_atm') {
            $note = sprintf(
                    $this->_trans('BACS Details :<br />Bank : Taishin Bank(Code : 812), Branch Code : 0687<br />Account : %s'),
                    $this->posted['EntityATM']
                ) . $this->_get_due_date_msg($DueDate);
        } else {
            $note = $this->_trans('Please') . $this->_trans('Print out the bill via email and pay at convenience store or post office.') . $this->_get_due_date_msg($DueDate);

            // 繳費單條碼訊息寫入後台
            if ($this->posted['SendType'] != 2) {
                $store_note = sprintf($this->_trans('Store Custom Bill Barcode Info : <br />CVS BARCODE 1 : %s<br />CVS BARCODE 2 : %s<br />CVS BARCODE 3 : %s<hr>POST BARCODE 1 : %s<br />POST BARCODE 2 : %s<br />POST BARCODE 3 : %s'),
                    $this->posted['BarcodeA'], $this->posted['BarcodeB'], $this->posted['BarcodeC'],
                    $this->posted['PostBarcodeA'], $this->posted['PostBarcodeB'], $this->posted['PostBarcodeC']
                );
                $order->add_order_note($store_note);
            }
        }

        $this->_add_order_note_and_response($order, $note, 'on-hold');
    }

    /**
     * Paycode 回傳
     *
     * @param $order
     */
    protected function payment_paycode($order)
    {
        $DueDate = $this->get_note1_arg('due_date');
        $note = $this->_trans('Please') . $this->_trans('Print out the bill via Multiple Media Kiosk and pay at convenience store.') .
            "<br />" . sprintf($this->_trans('CVS PayCode : %s'), $this->posted['paycode']) . $this->_get_due_date_msg($DueDate);

        $this->_add_order_note_and_response($order, $note, 'on-hold');
    }

    /**
     * Sunship 回傳
     *
     * @param WC_Order $order
     */
    protected function payment_sunship($order)
    {
        $StoreName = '7-ELEVEN - ' . $this->posted['StoreName'];
        $note = sprintf(
            $this->_trans("CVS Tracking Number : <a href='http://myship.7-11.com.tw/cc2b_track.asp?payment_no=%s' target='_blank'>%s</a><br />Pick-up Store : %s"),
            $this->posted['CargoNo'],
            $this->posted['CargoNo'],
            $StoreName
        );

        // 回填7-11門市名稱
        $shipping_info['address_1'] = $StoreName;
        $order->set_address($shipping_info, 'shipping');

        $this->_add_order_note_and_response($order, $note, 'processing');
    }

    /**
     * 交貨便 回傳
     *
     * @param $order
     */
    protected function payment_CVS($order)
    {
        $StoreType = $this->posted['StoreType'];
        $note = sprintf($this->_trans("Shipment Status Update : %s"), $this->posted['StoreMsg']);
        $status = 'processing';

        switch ($StoreType) {
            case '1010':
                $status = 'completed';
                break;
            case '1B1B':
                $status = 'cancelled';
                break;
        }

        $this->_add_order_note_and_response($order, $note, $status);
    }

    /**
     * Output for the order received page.
     *
     * @param WC_order $order
     * @param string $instructions
     * @param bool $payment_failed
     */
    private function thankyou_page($order, $instructions = null, $payment_failed = FALSE)
    {
        $notice_type = 'success';
        $redirect_url = $order->get_checkout_order_received_url();

        // 付款失敗
        if ($payment_failed) {
            $redirect_url = $order->get_cancel_order_url();
            $notice_type = 'error';
        }

        if (is_null($instructions)) $instructions = $notice_type;

        wc_add_notice($instructions, $notice_type);
        wp_safe_redirect(
            apply_filters('woocommerce_checkout_no_payment_needed_redirect', $redirect_url, $order)
        );
        exit;
    }

    /**
     * 取得note1中參數值
     * @param $string
     *
     * @return string
     */
    private function get_note1_arg($string)
    {
        parse_str($this->posted['note1']);
        switch ($string) {
            case 'due_date':
                $arg = isset($due_date) ? substr($due_date, 0, 4) . '/' . substr($due_date, 4, 2) . '/' . substr($due_date, 6, 2) : '';
                break;
            default:
                $arg = $$string;
        }
        return $arg;
    }

    /**
     * 更新訂單並回傳訊息
     *
     * @param WC_Order $order
     * @param string $note
     * @param string $set_order_status
     */
    private function _add_order_note_and_response($order, $note, $set_order_status)
    {
        $SendType = $this->posted['SendType'];
        $payment_fail = ($set_order_status == 'payment_fail') ? TRUE : FALSE;
        $set_note = TRUE;

        // 付款回傳 N 次(N > 1)，避免重複寫入備註
        if (($set_order_status == 'payment_complete' OR $set_order_status == 'payment_fail') AND !$order->has_status(array('pending', 'on-hold'))) {
            $set_note = FALSE;
        }

        if ($SendType != 2) {
            if ($set_note) $order->add_order_note($note, 1);

            // 更新訂單狀態
            switch ($set_order_status) {

                // 付款成功
                case 'payment_complete':
                    if (!$order->has_status('completed')) $order->payment_complete($this->posted['buysafeno']);
                    break;

                // 付款成功
                case 'payment_fail':
                    $order->update_status('cancelled');
                    break;

                // 非付款(24Payment、Paycode及物流回傳)
                default:
                    if (!$order->has_status('cancelled')) $order->update_status($set_order_status);
            }

            // 背景傳送則不轉頁，直接回應 0000
            echo '0000';
            exit;
        }

        $this->thankyou_page($order, $note, $payment_fail);
    }

    /**
     * @param $string
     * @return string
     */
    private function _trans($string)
    {
        return WC_Gateway_Suntech_Base::trans($string);
    }

    /**
     * @param $message
     * @param string $level
     */
    private function _log($message, $level = 'info')
    {
        return WC_Gateway_Suntech_Base::log($message, $level);
    }

    private function _get_due_date_msg($DueDate)
    {
        return sprintf(
            $this->_trans('<br />Payment Due Date : %s'),
            $DueDate
        );
    }

    /**
     * Save important data from the SunTech to the order.
     * @param WC_Order $order
     */
    protected function save_suntech_meta_data($order)
    {
        $posted = $this->posted;
        if (!empty($posted['buysafeno'])) {
            update_post_meta($order->get_id(), '_transaction_id', wc_clean($posted['buysafeno']));
        }
        if (!empty($this->get_note1_arg('payment_type'))) {
            update_post_meta($order->get_id(), 'Payment type', wc_clean($this->get_note1_arg('payment_type')));
        }
        if (!empty($posted['errcode'])) {
            update_post_meta($order->get_id(), '_suntech_status', wc_clean($posted['errcode']));
        }
    }

    /**
     * Send a notification to the user handling orders.
     * @param string $subject
     * @param string $message
     */
    protected function send_email_notification($subject, $message)
    {
        $new_order_settings = get_option('woocommerce_new_order_settings', array());
        $mailer = WC()->mailer();
        $message = $mailer->wrap_message($subject, $message);

        $mailer->send(!empty($new_order_settings['recipient']) ? $new_order_settings['recipient'] : get_option('admin_email'), strip_tags($subject), $message);
    }
}
