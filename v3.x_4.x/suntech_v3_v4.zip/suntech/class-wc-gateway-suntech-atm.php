<?php
/**
 * @package suntech
 * @version 1.2.2007
 **/
/*
 * Plugin Name: Suntech ATM
 * Plugin URI: https://www.esafe.com.tw/
 * Description: SunTech Payment Gateway for WooCommerce - Allows payments by direct bank/wire transfer or BACS
 * Author: SunTech
 * Version: 1.2.0811
 * Author URI: https://www.esafe.com.tw
 * Text Domain: suntech
 * Domain Path: /languages
 */
add_action('plugins_loaded', 'wc_suntech_atm_init');
function wc_suntech_atm_init()
{
    require_once dirname(__FILE__) . '/class-wc-gateway-suntech-base.php';

    class WC_Gateway_Suntech_ATM extends WC_Gateway_Suntech_Base
    {
        protected $bill_email;
        public function __construct()
        {
            parent::__construct();
            $this->id = 'suntech_atm';
            $this->sunpay_id = '24Pay';
            $this->has_fields = true;
            $this->method_title = $this->trans('ATM');
            $this->method_description .= $this->trans('Allows payments by direct bank/wire transfer or BACS');

            // Load the settings.
            $this->init_form_fields();
            $this->init_settings();

            // Define user set variables
            $this->enabled = $this->get_option('enabled');
            $this->test_mode = $this->get_option('test_mode');
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->web_value = $this->get_option('web_value');
            $this->web_password_value = $this->get_option('web_password_value');
            $this->order_button_text = $this->get_option('checkout_button_text');
            $due_days = (int)$this->get_option('due_days', 7);
            $this->due_date = date('Ymd', mktime(0, 0, 0, date("m"), date("d") + $due_days, date("Y")));
            $this->shipment = $this->get_option('shipment');
            $this->bill_email = $this->get_option('bill_email');
            $this->atmms = $this->get_option('atmms');

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));

            // SunTech response
            new WC_Gateway_SunTech_Response($this->id);
        }

        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => $this->trans('Enable/Disable'),
                    'type' => 'checkbox',
                    'description' => sprintf($this->trans("Must Activate SunTech %s Plugin First, <a href='%s' target='_blank'>%s</a>"),
                        '超商繳費單繳費',
                        network_admin_url('plugins.php'),
                        __('Activate Plugin')),
                    'label' => $this->trans('Enable'),
                    'default' => 'no'
                ),
                'test_mode' => array(
                    'title' => $this->trans('Test Mode'),
                    'type' => 'checkbox',
                    'label' => $this->trans('Enable'),
                    'default' => 'yes'
                ),
                'title' => array(
                    'title' => $this->trans('Title'),
                    'type' => 'text',
                    'description' => $this->trans('Payment method description that the customer will see on your checkout.', 'woocommerce'),
                    'default' => 'ATM轉帳（虛擬帳號）',
                    'desc_tip' => true
                ),
                'description' => array(
                    'title' => $this->trans('Description'),
                    'type' => 'textarea',
                    'description' => $this->trans('Payment method description that the customer will see on your website.', 'woocommerce'),
                    'default' => $this->trans('Payments by BACS'),
                    'desc_tip' => true
                ),
                'web_value' => array(
                    'title' => $this->trans('Merchant ID(web)'),
                    'type' => 'text',
                    'description' => sprintf($this->trans('SunTech %s Merchant ID(web)<br />Receive / Confirm URL : <b>%s</b>'),
                        '超商代收',
                        network_site_url() . "/?wc-api=WC_Gateway_Suntech_" . $this->sunpay_id)
                ),
                'web_password_value' => array(
                    'title' => $this->trans('Transaction Password'),
                    'type' => 'password',
                    'description' => $this->trans('SunTech Transaction Password'),
                ),
                'checkout_button_text' => array(
                    'title' => $this->trans('Checkout Button Text'),
                    'type' => 'text',
                    'default' => $this->trans('Checkout', 'woocommerce')
                ),
                //
                // class-wc-gateway-suntech-base.php line:59
                //
                // 'pay_button_text' => array(
                //     'title' => $this->trans('Pay Button Text'),
                //     'type' => 'text',
                //     'default' => $this->trans('Pay for order', 'woocommerce')
                // ),
                'due_days' => array(
                    'title' => $this->trans('Due Days'),
                    'type' => 'number',
                    'description' => '0 ~ 180',
                    'default' => '7',
                    'desc_tip' => true
                ),
                //'shipment' => array(
                //    'title' => $this->trans('Enable CVS Pick-up'),
                //    'type' => 'checkbox',
                //    'label' => $this->trans('Enable'),
                //    'default' => 'no'
                //),
                'atmms' => array(
                    'title' => $this->trans("Please Select atm Plan"),
                    'type' => 'multiselect',
                    'class' => 'wc-enhanced-select',
                    'css' => 'width: 400px;',
                    'description' => $this->trans("Press CTRL and the left button on the mouse to select multi payments."),
                    'default' => 'T',
                    'options' => array(
                        'T' => '合作金庫',
                        'H' => '彰化銀行'
                    )
                ),
                'bill_email' => array(
                    'title' => $this->trans('Bill e-mail'),
                    'type' => 'email',
                    'default' => get_option('admin_email'),
                    'description' => $this->trans('Catching SunTech bill instead of sending to the customer'),
                    'required' => 'required',
                    'desc_tip' => true
                ),
            );
        }

        /**
         * SunTech Payment required additional args in html
         *
         * @param WC_Order $order
         * @return string
         */
        public function get_payment_additional_html($order)
        {
            $cur_user = wp_get_current_user();
            $_UserNo = $cur_user->ID > 0 ? $cur_user->ID : $this->_sna;
            $html = '<input type="hidden" name="DueDate" value="' . $this->due_date . '"> 
                 <input type= "hidden" name="AgencyBank" value="' . WC()->session->get('suntech_choose_atmm') . '">
                 <input type= "hidden" name="AgencyType" value="2">
                <input type="hidden" name="UserNo" value="' . $_UserNo . '">
                ' . $this->get_bill_items_inputs($order) ;
                //'<input type= "hidden" name="CargoFlag" value="' . WC()->session->get('suntech_choose_shipment') . '">';

            return $html;
        }

        public function validate_enabled_field($key, $value)
        {
            $yesorno = 'no';

            if ($value == '1') {
                if (!in_array('suntech/class-wc-gateway-suntech-' . strtolower($this->sunpay_id) . '.php', apply_filters('active_plugins', get_option('active_plugins')))) $yesorno = 'no';
                else $yesorno = 'yes';
            }

            return $yesorno;
        }

        public function validate_due_days_field($key, $value)
        {
            $value = (int)$value;
            switch (true) {
                case ($value < 0):
                    return 0;
                case ($value > 180):
                    return 180;
                default:
                    return $value;
            }
        }

        public function validate_bill_email_field($key, $value)
        {
            return is_email($value) ? $value : get_option('admin_email');
        }

        public function payment_fields()
        {
            if (!empty($this->description)) {
                echo '<p>' . $this->description . '</p>';
            }

            if ($this->atmms) {
                echo '<div style="padding-top: 10px"><label for="atmms">';
                echo $this->trans('Please Select atmm Plan');
                echo '</label>';
                echo '<select name="atmms" id="atmms" style="margin-left: 5px;width: 60%;">';
                foreach ($this->atmms as $atmms_option) {
                    echo '<option value="' . $atmms_option . '">';
                    echo $this->trans($atmms_option . " atmms");
                    echo '</option>';
                }
                echo '</select></div>';
            }

            //if ($this->shipment == 'yes') {
            //    echo '<div style="padding-top: 10px"><label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">';
            //    echo '<input type="checkbox" name="shipment" value="ship" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" />';
            //    echo '<span>' . $this->trans('CVS Pick-up') . '</span></label></div>';
            //}
        }

        public function validate_fields()
        {
            
            $validate_atmms = TRUE;
            $choose_atmms = isset($_POST['atmms']) ? $_POST['atmms'] : '';
            if ($choose_atmms) {
                if (in_array($choose_atmms, $this->atmms)) {
                    $this->choose_atmm = $choose_atmms;
                } else $validate_atmms = FALSE;
            }

            $validate = $validate_atmms;

            if ($validate) wc_add_notice($this->trans('Thank you for your order! Please click the button to enter the checkout process.'));
            else wc_add_notice($this->trans('An error occurred. Please re-select.'), 'error');

            return $validate;
        }

    }

    function add_suntech_atm_gateway($methods)
    {
        $methods[] = 'WC_Gateway_Suntech_ATM';
        return $methods;
    }

    add_filter('woocommerce_payment_gateways', 'add_suntech_atm_gateway');
}

