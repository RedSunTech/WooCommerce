<?php
/**
 * @package suntech
 * @version 1.2.0811
 **/
/*
 * Plugin Name: SunTech Logistics familyB
 * Plugin URI: https://www.esafe.com.tw/
 * Description: SunTech Logistics Gateway for WooCommerce -紅陽物流功能 familyB
 * Author: SunTech
 * Version: 1.2.0811
 * Author URI: https://www.esafe.com.tw
 * Text Domain: suntech
 * Domain Path: /languages
 *
 *///可愛胖胖開發 fatfat develop 2020/11/03
defined( 'ABSPATH' ) || exit;

if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) { 
	add_action('plugins_loaded', 'logistics_suntech_familyB_init');
    function logistics_suntech_familyB_init() { 



     if (! class_exists('WC_Logistics_Suntech_familyB')) { 
	 
      class WC_Logistics_Suntech_familyB extends WC_Shipping_Method { 
		
       /** 
       * Constructor for your shipping class 
       * 
       * @access public 
       * @return void 
       */ 
	   public $cost = '';
	   
       public function __construct( $instance_id = 0 ) { 

        $this->id     = 'logistics_suntech_familyB'; // Id for your shipping method. Should be uunique. 
		$this->instance_id        = absint( $instance_id );
        $this->method_title  = '全家'; // Title shown in admin 
        $this->method_description = __('SunTech Logistics Gateway for WooCommerce - familyB','suntech'); // Description shown in admin 
		
        $this->title = "全家"; // This can be added as an setting but for this example its forced. 

        $this->supports = array(
         'shipping-zones',
		 'instance-settings',
		 'instance-settings-modal',
        ); 

        $this->init(); 

		// Save settings in admin if you have any defined 
        add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options')); 

       } 

       /** 
       * Init your settings 
       * 
       * @access public 
       * @return void 
       */ 
       function init() { 
        // Load the settings API 
        $this->init_form_fields(); // This is part of the settings API. Override the method to add your own settings 
        $this->init_settings(); // This is part of the settings API. Loads settings you previously init. 
		$this->cost = $this->get_option( 'cost' );

		// 隱藏與顯示貨到付款金流
        //add_filter('woocommerce_payment_gateways', array($this, 'wcso_filter_available_payment_gateways'), 10, 1);
		
		
        
       } 

       function init_form_fields() { 
			//$cost_desc = __( 'Enter a cost (excl. tax) or sum, e.g. <code>10.00 * [qty]</code>.', 'woocommerce' ) . '<br/><br/>' . __( 'Use <code>[qty]</code> for the number of items, <br/><code>[cost]</code> for the total cost of items, and <code>[fee percent="10" min_fee="20" max_fee=""]</code> for percentage based fees.', 'woocommerce' );
			$this->instance_form_fields = array(
			
			'cost'       => array(
				'title' => '請輸入運費',
                'type' => 'text',
                'description' => '請輸入運費',
                'desc_tip' => true,
                'default' => 60,
				),
			); 

       } 

       /** 
       * calculate_shipping function. 
       * 
       * @access public 
       * 
       * @param mixed $package 
       * 
       * @return void 
       */ 

		public function calculate_shipping( $package = array() ) {
			
			$this->add_rate(
				array(
					'label'   => $this->title,
					'cost'    => $this->cost,
					'package' => $package,
				)
			);
		}
      } 
     } 
	  new WC_Logistics_Suntech_familyB();
	  
    } 

    add_action('woocommerce_shipping_init', 'logistics_suntech_familyB_init'); 

    function request_shipping_familyB_shipping_method($methods) { 
        $methods['logistics_suntech_familyB'] = 'WC_Logistics_Suntech_familyB'; 
        return $methods; 
    } 
    add_filter('woocommerce_shipping_methods', 'request_shipping_familyB_shipping_method'); 


    function familyB_remove_unused_payment_gateways( $load_gateways ) {

        global $woocommerce;

        $chosen_method = $woocommerce->session->get('chosen_shipping_methods');

        $remove_gateways = array();
            
        if( strpos($chosen_method[0], 'logistics_suntech_familyB') !== false) {

            foreach ( $load_gateways as $key => $value ) {
                if(strpos($value, 'Suntech') === false){
                    array_push($remove_gateways,$value);
                }
                    
            }
        }

        foreach ( $load_gateways as $key => $value ) {

            if ( in_array( $value, $remove_gateways ) ) {
                unset( $load_gateways[ $key ] );
            }
        }

        return $load_gateways;
    }
    

    if(has_action( 'woocommerce_checkout_fields', 'bbloomer_shipping_phone_checkout' ) == false && !is_admin()){
        function bbloomer_shipping_phone_checkout( $fields ) {
            $fields['shipping']['shipping_phone'] = array(
            'label' => '收件者手機',
            'required' => true,
            'class' => array( 'form-row-wide' ),
            'priority' => 25,
            );
            $fields['shipping']['shipping_note'] = array(
                'type'  => 'hidden',
                'required' => false,
                'class' => array( 'form-row-wide' ),
                'priority' => 25,
            );
            return $fields;
        }
    }


    if(has_action( 'woocommerce_order_details_after_customer_details', 'bbloomer_shipping_phone_checkout_display' ) == false){
        function bbloomer_shipping_phone_checkout_display( $order ){

            echo '<div class="woocommerce-column woocommerce-column--1 woocommerce-column--billing-address col-12">';
            echo '<h2 class="woocommerce-column__title mt-3">紅陽科技 - 其他資訊</h2>';
            echo '<address>';
            echo '<p><b>收件者手機:</b> ' . get_post_meta( $order->get_id(), '_shipping_phone', true ) . '</p>';
            if(get_post_meta( $order->get_id(), '_shipping_note', true ) != '')
                echo '<p><b>運送狀態:</b> ' . get_post_meta( $order->get_id(), '_shipping_note', true ) . '</p>';
            echo '</address>';
            echo '</div>';
        }
        add_action( 'woocommerce_admin_order_data_after_shipping_address', 'bbloomer_shipping_phone_checkout_display' );
        add_action( 'woocommerce_order_details_after_customer_details', 'bbloomer_shipping_phone_checkout_display' );
    }




    
/*
     add_filter( 'woocommerce_shipping_fields', 'add_shipping_phone_field' );
     function add_shipping_phone_field( $fields ) {
        $fields['shipping_phone'] = array(
           'label' => __('Phone (Shipping)'),
           'required' => true,
           'class' => array( 'form-row-wide' ),
           'priority' => 25,
        );
        return $fields;
     }



    add_filter( 'woocommerce_order_formatted_shipping_address', 'add_shipping_phone_to_formatted_shipping_address', 100, 2 );
    function add_shipping_phone_to_formatted_shipping_address( $shipping_address, $order ) {
        global $pagenow, $post_type;
    
        // Not on admin order edit pages (as it's already displayed).
        if( ! ( $pagenow === 'post.php' && $post_type === 'shop_order' && isset($_GET['action']) && $_GET['action'] === 'edit' ) ) {
            // Include shipping phone on formatted shipping address
            $shipping_address['phone'] = $order->get_meta('_shipping_phone');
        }
        return $shipping_address;
    }






    add_filter( 'woocommerce_formatted_address_replacements', 'custom_formatted_address_replacements', 10, 2 );
    function custom_formatted_address_replacements( $replacements, $args  ) {
        $replacements['{phone}'] = ! empty($args['phone']) ? $args['phone'] : '';
    
        return $replacements;
    }
*/

    
    if (!is_admin()) {
        add_filter( 'woocommerce_checkout_fields', 'bbloomer_shipping_phone_checkout' );
        add_filter( 'woocommerce_payment_gateways', 'familyB_remove_unused_payment_gateways', 20, 1 );
    }
	
}