<?php
/**
 * @package suntech
 * @version 1.2.0811
 **/
/*
 * Plugin Name: SunTech BuySafe
 * Plugin URI: https://www.esafe.com.tw/
 * Description: SunTech Payment Gateway for WooCommerce - Online Credit Card Payment
 * Author: SunTech
 * Version: 1.2.0811
 * Author URI: https://www.esafe.com.tw
 * Text Domain: suntech
 * Domain Path: /languages
 */
add_action('plugins_loaded', 'wc_suntech_buysafe_init');
function wc_suntech_buysafe_init()
{
    require_once dirname(__FILE__) . '/class-wc-gateway-suntech-base.php';

    class WC_Gateway_Suntech_BuySafe extends WC_Gateway_Suntech_Base
    {
        public function __construct()
        {
            parent::__construct();
            $this->id = 'suntech_buysafe';
            $this->sunpay_id = 'BuySafe';
            $this->method_title = $this->trans('Credit');
            $this->method_description .= $this->trans('Online Credit Card Payment');

            // Load the settings.
            $this->init_form_fields();
            $this->init_settings();

            // Define user set variables
            $this->enabled = $this->get_option('enabled');
            $this->test_mode = $this->get_option('test_mode');
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->web_value = $this->get_option('web_value');
            $this->web_password_value = $this->get_option('web_password_value');
            $this->order_button_text = $this->get_option('checkout_button_text');
            // $this->installments = $this->get_option('installments');
            //$this->shipment = $this->get_option('shipment');

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));

            // SunTech response
            new WC_Gateway_SunTech_Response($this->id);
        }

        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => $this->trans('Enable/Disable'),
                    'type' => 'checkbox',
                    'label' => $this->trans('Enable'),
                    'default' => 'no'
                ),
                'test_mode' => array(
                    'title' => $this->trans('Test Mode'),
                    'type' => 'checkbox',
                    'label' => $this->trans('Enable'),
                    'default' => 'yes'
                ),
                'title' => array(
                    'title' => $this->trans('Title'),
                    'type' => 'text',
                    'description' => $this->trans('Payment method description that the customer will see on your checkout.', 'woocommerce'),
                    'default' => '信用卡一次付清',
                    'desc_tip' => true
                ),
                'description' => array(
                    'title' => $this->trans('Description'),
                    'type' => 'textarea',
                    'description' => $this->trans('Payment method description that the customer will see on your website.', 'woocommerce'),
                    'default' => '信用卡刷卡一次付清',
                    'desc_tip' => true
                ),
                'web_value' => array(
                    'title' => $this->trans('Merchant ID(web)'),
                    'type' => 'text',
                    'description' => sprintf($this->trans('SunTech %s Merchant ID(web)<br />Receive / Confirm URL : <b>%s</b>'),
                        '信用卡(購物車)',
                        network_site_url() . "/?wc-api=WC_Gateway_Suntech_" . $this->sunpay_id)
                ),
                'web_password_value' => array(
                    'title' => $this->trans('Transaction Password'),
                    'type' => 'password',
                    'description' => $this->trans('SunTech Transaction Password'),
                ),
                'checkout_button_text' => array(
                    'title' => $this->trans('Checkout Button Text'),
                    'type' => 'text',
                    'default' => $this->trans('Checkout', 'woocommerce')
                ),
                //
                // class-wc-gateway-suntech-base.php line:59
                //
                // 'pay_button_text' => array(
                //     'title' => $this->trans('Pay Button Text'),
                //     'type' => 'text',
                //     'default' => $this->trans('Pay for order', 'woocommerce')
                // ),
                // 'installments' => array(
                //     'title' => $this->trans("Please Select Installment Plan"),
                //     'type' => 'multiselect',
                //     'class' => 'wc-enhanced-select',
                //     'css' => 'width: 400px;',
                //     'description' => $this->trans("Press CTRL and the left button on the mouse to select multi payments."),
                //     'options' => array(
                //         '3' => $this->trans("3 Installments"),
                //         '6' => $this->trans("6 Installments"),
                //         '12' => $this->trans("12 Installments"),
                //         '18' => $this->trans("18 Installments"),
                //         '24' => $this->trans("24 Installments")
                //     )
                // ),
                // 'shipment' => array(
                //     'title' => $this->trans('Enable CVS Pick-up'),
                //     'type' => 'checkbox',
                //     'label' => $this->trans('Enable'),
                //     'default' => 'no'
                // ),
            );
        }

        /**
         * SunTech Payment required additional args in html
         *
         * @param WC_Order $order
         * @return string
         */
        public function get_payment_additional_html($order)
        {
            $html = '<input type= "hidden" name="Card_Type" value="0">' .
                '<input type= "hidden" name="Term" value="' . WC()->session->get('suntech_choose_installment') . '">' ;
                //'<input type= "hidden" name="CargoFlag" value="' . WC()->session->get('suntech_choose_shipment') . '">';

            return $html;
        }

        public function payment_fields()
        {
            if (!empty($this->description)) {
                echo '<p>' . $this->description . '</p>';
            }
            // if ($this->installments) {
            //     echo '<div style="padding-top: 10px"><label for="installments">';
            //     echo $this->trans('Please Select Installment Plan');
            //     echo '</label>';
            //     echo '<select name="installments" id="installments" style="margin-left: 5px;width: 60%;">';
            //     echo '<option value="1">' . $this->trans('Lump Sum') . '</option>';
            //     foreach ($this->installments as $installments_option) {
            //         echo '<option value="' . $installments_option . '">';
            //         echo $this->trans($installments_option . " Installments");
            //         echo '</option>';
            //     }
            //     echo '</select></div>';
            // }

            // if ($this->shipment == 'yes') {
            //     echo '<div style="padding-top: 10px"><label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">';
            //     echo '<input type="checkbox" name="shipment" value="ship" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" />';
            //     echo '<span>' . $this->trans('CVS Pick-up') . '</span></label></div>';
            // }
        }

        public function validate_fields()
        {
            // $validate_installments = TRUE;
            // $choose_installments = isset($_POST['installments']) ? $_POST['installments'] : '';
            // if (is_numeric($choose_installments) && $choose_installments > 1) {
            //     if (in_array($choose_installments, $this->installments)) {
            //         $this->choose_installment = $choose_installments;
            //     } else $validate_installments = FALSE;
            // }

            // $validate_shipment = $this->validate_shipment_fields();
            // $validate = $validate_installments && $validate_shipment;

            // if ($validate) wc_add_notice($this->trans('Thank you for your order! Please click the button to enter the checkout process.'));
            // else wc_add_notice($this->trans('An error occurred. Please re-select.'), 'error');

            // return $validate;
        }
    }

    function add_suntech_buysafe_gateway($methods)
    {
        $methods[] = 'WC_Gateway_Suntech_BuySafe';
        return $methods;
    }

    add_filter('woocommerce_payment_gateways', 'add_suntech_buysafe_gateway');
}

