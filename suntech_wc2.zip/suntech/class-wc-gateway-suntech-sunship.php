<?php
/**
 * @package suntech
 * @version 1.2.0815
 **/
/*
 * Plugin Name: SunTech SunShip
 * Plugin URI: https://www.esafe.com.tw/
 * Description: SunTech Payment Gateway for WooCommerce - Pick-up and Pay at convenience store
 * Author: SunTech
 * Version: 1.2.0815
 * Author URI: https://www.esafe.com.tw
 * Text Domain: suntech
 * Domain Path: /languages
 */
add_action('plugins_loaded', 'wc_suntech_sunship_init');
function wc_suntech_sunship_init()
{
    require_once dirname(__FILE__) . '/class-wc-gateway-suntech-base.php';

    class WC_Gateway_Suntech_SunShip extends WC_Gateway_Suntech_Base
    {
        public function __construct()
        {
            parent::__construct();
            $this->id = 'suntech_sunship';
            $this->sunpay_id = 'SunShip';
            $this->method_title = $this->trans('SunShip');
            $this->method_description .= $this->trans('Pick-up and Pay at convenience store');

            // Load the settings.
            $this->init_form_fields();
            $this->init_settings();

            // Define user set variables
            $this->enabled = $this->get_option('enabled');
            $this->test_mode = $this->get_option('test_mode');
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->web_value = $this->get_option('web_value');
            $this->web_password_value = $this->get_option('web_password_value');
            $this->order_button_text = $this->get_option('checkout_button_text');

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));

            // SunTech response
            new WC_Gateway_SunTech_Response($this->id);
        }

        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => $this->trans('Enable/Disable'),
                    'type' => 'checkbox',
                    'label' => $this->trans('Enable'),
                    'default' => 'no'
                ),
                'test_mode' => array(
                    'title' => $this->trans('Test Mode'),
                    'type' => 'checkbox',
                    'label' => $this->trans('Enable'),
                    'default' => 'yes'
                ),
                'title' => array(
                    'title' => $this->trans('Title'),
                    'type' => 'text',
                    'description' => $this->trans('Payment method description that the customer will see on your checkout.', 'woocommerce'),
                    'default' => $this->trans('SunShip'),
                    'desc_tip' => true
                ),
                'description' => array(
                    'title' => $this->trans('Description'),
                    'type' => 'textarea',
                    'description' => $this->trans('Payment method description that the customer will see on your website.', 'woocommerce'),
                    'default' => $this->trans('Pick-up and Pay at convenience store'),
                    'desc_tip' => true
                ),
                'web_value' => array(
                    'title' => $this->trans('Merchant ID(web)'),
                    'type' => 'text',
                    'description' => sprintf($this->trans('SunTech %s Merchant ID(web)<br />Receive / Confirm URL : <b>%s</b>'),
                        $this->sunpay_id,
                        network_site_url() . "/?wc-api=WC_Gateway_Suntech_" . $this->sunpay_id)
                ),
                'web_password_value' => array(
                    'title' => $this->trans('Transaction Password'),
                    'type' => 'password',
                    'description' => $this->trans('SunTech Transaction Password'),
                ),
                'checkout_button_text' => array(
                    'title' => $this->trans('Checkout Button Text'),
                    'type' => 'text',
                    'default' => $this->trans('Checkout', 'woocommerce')
                ),
                //
                // class-wc-gateway-suntech-base.php line:59
                //
                // 'pay_button_text' => array(
                //     'title' => $this->trans('Pay Button Text'),
                //     'type' => 'text',
                //     'default' => $this->trans('Pay for order', 'woocommerce')
                // )
            );
        }

        public function payment_fields()
        {
            if (!empty($this->description)) {
                echo '<p>' . $this->description . '</p>';
            }
        }

        public function validate_fields()
        {
            wc_add_notice($this->trans('Thank you for your order! Please click the button to enter the checkout process.'));
            return TRUE;
        }
    }

    function add_suntech_sunship_gateway($methods)
    {
        $methods[] = 'WC_Gateway_Suntech_SunShip';
        return $methods;
    }

    add_filter('woocommerce_payment_gateways', 'add_suntech_sunship_gateway');
}

