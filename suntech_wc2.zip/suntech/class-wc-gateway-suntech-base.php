<?php
/**
 * @package suntech
 *
 * */

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

// Make sure WooCommerce is active
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) return;

abstract class WC_Gateway_Suntech_Base extends WC_Payment_Gateway
{
    protected $sunpay_id;
    protected $web_value = '', $web_password_value = '', $test_mode, $ChkValue, $shipment, $domain;
    protected $installments, $due_date = '', $_sna;
    protected $choose_installment = '', $choose_shipment = 0;

    public function __construct()
    {
        load_plugin_textdomain('suntech', FALSE, dirname(plugin_basename(__FILE__)) . '/languages/');
        $this->method_description = '<h3>' . __('SunTech Payment', 'suntech') . '</h3>';

        // SunTech response
        include_once(dirname(__FILE__) . '/includes/class-wc-gateway-suntech-response.php');

        $this->icon = apply_filters('woocommerce_suntech_icon', plugins_url('assets/images/suntech.png', __FILE__));
        $this->has_fields = true;
    }

    /**
     * Receipt page.
     *
     * @param  int $order_id
     */
    function receipt_page($order_id)
    {
        $order = new WC_Order($order_id);

        // 超商取貨付款，交易金額不得低於50元，導到訂單付款頁
        if ($this->sunpay_id == 'SunShip' && $order->get_total() < 50) {
            wc_add_notice($this->trans('When using SunShip payment, transaction amount must be equal or larger than NT$50'), 'error');
            wp_safe_redirect(
                $order->get_checkout_payment_url()
            );
            exit;
        }

        // Clean the cart
        WC()->cart->empty_cart();

        $payment_html = $this->get_payment_html($order);
        WC()->session->set('suntech_choose_installment', '');
        WC()->session->set('suntech_choose_shipment', '');

        // 直接轉跳至紅陽支付畫面，相同訂單編號(Td)無法重複交易
        $order->update_status('on-hold', $this->trans('SunPay Transaction'));
        echo $this->submit_suntech_form($payment_html);

        // 停留在 receipt page
        // echo $this->suntech_form($payment_html, $this->get_option('pay_button_text'));
    }

    protected function suntech_form($form_inputs = '', $btn_submit_txt = '結帳')
    {
        if ($this->get_option('test_mode') == 'yes') $action = 'https://test.esafe.com.tw/Service/Etopm.aspx';
        else $action = 'https://www.esafe.com.tw/Service/Etopm.aspx';

        $html = '<form id="form_suntech_submit" method="post" action="' . $action . '">';
        $html .= $form_inputs;
        $html .= '<input type="submit" id="btn_submit_suntech" value="' . $btn_submit_txt . '"></form>';

        return $html;
    }

    protected function submit_suntech_form($form_inputs = '')
    {
        if ($this->get_option('test_mode') == 'yes') $action = 'https://test.esafe.com.tw/Service/Etopm.aspx';
        else $action = 'https://www.esafe.com.tw/Service/Etopm.aspx';

        $html = '<html><head><meta charset="utf-8"></head><body>';
        $html .= '<form id="__suntech_form" method="post" action="' . $action . '">';
        $html .= $form_inputs;
        $html .= '</form><script type="text/javascript">document.getElementById("__suntech_form").submit();</script>';
        $html .= '</body></html>';

        return $html;
    }

    public function validate_shipment_fields()
    {
        $choose_shipment = isset($_POST['shipment']) ? $_POST['shipment'] : '';
        switch ($choose_shipment) {
            case '':
                $this->shipment = '0';
                return TRUE;
                break;
            case 'ship':
                if ($this->shipment == 'yes') {
                    $this->choose_shipment = '1';
                    if (!preg_match("/09[0-9]{2}[0-9]{6}/", filter_input(INPUT_POST, 'billing_phone'))) {
                        wc_add_notice($this->trans('With the convenience store pick-up, the contact phone number must be mobile phone number, example : 0912345678'), 'error');
                        return FALSE;
                    }
                }
                return TRUE;
                break;
            default:
                return FALSE;
        }
    }

    function process_payment($order_id)
    {
        $order = new WC_Order($order_id);

        $payment_str = " (" . $this->title;
        if ($this->choose_installment != '') {
            WC()->session->set('suntech_choose_installment', $this->choose_installment);
            $payment_str .= ", " . $this->trans($this->choose_installment . " Installments");
        }

        WC()->session->set('suntech_choose_shipment', $this->choose_shipment);
        if ($this->choose_shipment == '1' || $this->id == 'suntech_sunship') {
            $payment_str .= ", " . $this->trans("CVS Pick-up");
            $shipping_info = array(
                'city' => '',
                'state' => '',
                'postcode' => '',
                'address_1' => '7-ELEVEN',
                'address_2' => ''
            );
            $order->set_address($shipping_info, 'shipping');
        }
        else {
            if ($order->shipping_city == '') {
                $shipping_info = array(
                    'city' => $order->billing_city,
                    'state' => $order->billing_state,
                    'postcode' => $order->billing_postcode,
                    'address_1' => $order->billing_address_1,
                    'address_2' => $order->billing_address_2
                );
                $order->set_address($shipping_info, 'shipping');
            }
        }

        $payment_str .= ")";

        if ($this->get_order_init_notes($order_id) != '') {
            $order->add_order_note($this->trans("Change Payment GateWay, Pending Payment") . $payment_str, 1);
        } else {
            $order->add_order_note($this->trans("New Order, Pending Payment") . $payment_str, 1);
        }

        return array('result' => 'success', 'redirect' => $order->get_checkout_payment_url(true));
    }

    /**
     * SunTech Payment required additional args in html
     *
     * @param WC_Order $order
     * @return string
     */
    protected function get_payment_additional_html($order)
    {
        return '';
    }

    /**
     * Suntech required args in html
     *
     * @param WC_Order $order
     * @return string
     */
    function get_payment_html($order)
    {
        $total_amount = $order->get_total();
        $_Td = $order->id;
        $_OrderInfo = urlencode(
            sprintf($this->trans("New order from %s, order id : %s, created at %s."), $_SERVER['SERVER_NAME'], $_Td, $order->order_date)
        );

        $_ChkValue = $this->get_post_submit_ChkValue($this->web_value, $this->web_password_value, $total_amount, WC()->session->get('suntech_choose_installment'));
        $this->_sna = $order->billing_first_name . $order->billing_last_name;
        $_email = $order->billing_email;
        if ($this->id == 'suntech_atm') {
            $_email = $this->get_option('bill_email');
        }

        // note1
        $note1 = array();
        $note1['payment_type'] = $this->id;
        if (!empty($this->due_date)) $note1['due_date'] = $this->due_date;

        $html = '<input type="hidden" name="web" value="' . $this->web_value . '">
                <input type="hidden" name="MN" value="' . $total_amount . '">
                <input type="hidden" name="Td" value="' . $_Td . '">
                <input type="hidden" name="OrderInfo" value="' . $_OrderInfo . '">
                <input type="hidden" name="sna" value="' . $this->_sna . '">
                <input type="hidden" name="sdt" value="' . $order->billing_phone . '">
                <input type="hidden" name="email" value="' . $_email . '">
                <input type="hidden" name="note1" value="' . urlencode(http_build_query($note1)) . '">
                <input type="hidden" name="ChkValue" value="' . $_ChkValue . '">';

        $html .= $this->get_payment_additional_html($order);

        return $html;
    }

    /**
     * SunTech Payments - 24Payment required order's item list
     *
     * @param WC_Order $order
     * @return string $bill_items_inputs
     */
    function get_bill_items_inputs($order)
    {
        $idx = 1;
        $bill_items = array();
        $additional_bill_items = array();
        $items = $order->get_items();

        if (!count($items)) wp_die($this->trans("An error occurred. Please re-select."), 'SunTech Payment', array('response' => 500));

        // additional bill list
        if ($order->get_total_discount() > 0) $additional_bill_items[] = array('qty' => 1, 'name' => __('Coupon(s)', 'woocommerce'), 'amount' => $order->get_total_discount() * -1);
        if ($order->get_total_shipping() > 0) $additional_bill_items[] = array('qty' => 1, 'name' => __('Shipping amount', 'woocommerce'), 'amount' => $order->get_total_shipping());
        if ($order->get_total_tax() > 0) $additional_bill_items[] = array('qty' => 1, 'name' => __('Total tax', 'woocommerce'), 'amount' => $order->get_total_tax());

        if (count($items) + count($additional_bill_items) > 10) {
            $i = $remaining_items_amount = 0;
            while ($item = array_pop($items)) {
                $i++;
                $qty = $item['qty'];
                $name = $item['name'];
                $amount = $order->get_item_subtotal($item, false);
                if (($i + count($additional_bill_items)) >= 10) {
                    $remaining_items_amount += $amount;
                } else {
                    $bill_items[] = array('qty' => $qty, 'name' => $name, 'amount' => $amount);
                }
            }
            $bill_items[] = array('qty' => 1, 'name' => __('The remaining items'), 'amount' => $remaining_items_amount);
        } else {
            foreach ($items as $key => $item) {
                $qty = $item['qty'];
                $name = $item['name'];
                $amount = $order->get_item_subtotal($item, false);
                $bill_items[] = array('qty' => $qty, 'name' => $name, 'amount' => $amount);
            }
        }

        // Merge
        $bill_items = array_merge($bill_items, $additional_bill_items);

        // 產生HTML
        $bill_items_inputs = '';
        foreach ($bill_items as $item) {
            $str_input = '';//reset
            $str_input .= '<input type="hidden" name="ProductName' . $idx . '" value="' . $item['name'] . '">';
            $str_input .= '<input type="hidden" name="ProductPrice' . $idx . '" value="' . (int)$item['amount'] . '">';
            $str_input .= '<input type="hidden" name="ProductQuantity' . $idx . '" value="' . $item['qty'] . '">';
            $bill_items_inputs .= $str_input;
            $idx++;
        }

        return $bill_items_inputs;
    }

    function add_suntech_product($ary_product, $qty, $name, $price)
    {
        $ary_product[] = array('qty' => $qty, 'name' => $name, 'price' => $price);
        return $ary_product;
    }

    function get_post_submit_ChkValue($web, $web_password, $total_amount, $term = "")
    {
        $args = array($web, $web_password, $total_amount, $term);
        $implode_args = implode('', $args);
        return self::get_encrypted_ChkValue($implode_args);
    }

    public function get_order_init_notes($order_id)
    {
        $comment = '';

        $args = array(
            'post_id' => $order_id,
            'orderby' => 'comment_ID',
            'order' => 'ASC',
            'approve' => 'approve',
            'type' => 'order_note',
        );
        remove_filter('comments_clauses', array('WC_Comments', 'exclude_order_comments'));
        $comments = get_comments($args);
        add_filter('comments_clauses', array('WC_Comments', 'exclude_order_comments'));

        if (count($comments) > 0) {
            $comment = $comments[0];
        }
        return $comment;
    }

    public function validate_pay_button_text_field($key, $value)
    {
        return empty($value) ? $this->_get_field_default($key) : $value;
    }

    /**
     * Get field default value
     *
     * @param $key
     * @return string
     */
    protected function _get_field_default($key)
    {
        $form_fields = $this->get_form_fields();
        return isset($form_fields[$key]) ? $this->get_field_default($form_fields[$key]) : '';
    }

    /**
     * @param string $string
     * @param string $domain
     *
     * @return string
     */
    public static function trans($string, $domain = 'suntech')
    {
        return __($string, $domain);
    }

    /**
     * Logging method.
     *
     * @param string $message Log message.
     * @param string $level Optional. Default 'info'
     *     emergency|alert|critical|error|warning|notice|info|debug
     */
    public static function log($message, $level = 'info')
    {
        $logger = new WC_Logger();
        $logger->add($level, $message);
    }

    /**
     * Get encrypted ChkValue
     * @param string $implode_args
     * @return string
     */
    public static function get_encrypted_ChkValue($implode_args)
    {
        return strtoupper(sha1($implode_args));
    }
}


